import { useState, useEffect } from "react";
import { Menu, X, Phone, MessageCircle, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

const navLinks = [
  { name: "Home", href: "#home" },
  { name: "About", href: "#about" },
  { name: "Academics", href: "#academics" },
  { name: "Facilities", href: "#facilities" },
  { name: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 py-4 border-b",
        isScrolled ? "bg-background/95 backdrop-blur-md border-border shadow-lg py-3" : "bg-transparent border-transparent"
      )}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary rounded flex items-center justify-center text-background font-serif font-bold text-xl">
            K
          </div>
          <div className="flex flex-col">
            <span className="font-serif text-xl tracking-wider text-foreground">KEMS BOARDING</span>
          </div>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-[13px] uppercase tracking-[1.5px] font-medium text-secondary hover:text-primary transition-colors"
            >
              {link.name}
            </a>
          ))}
          <Button className="cta-btn-outline h-auto py-2">
            Admissions
          </Button>
        </div>

        {/* Mobile Nav */}
        <div className="md:hidden flex items-center gap-4">
          <a href="https://t.ly/tnoHz" target="_blank" rel="noreferrer" className="text-green-600">
            <MessageCircle size={24} />
          </a>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu size={24} />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px]">
              <div className="flex flex-col gap-8 mt-12">
                {navLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    className="text-2xl font-display font-bold text-primary hover:text-secondary transition-colors"
                  >
                    {link.name}
                  </a>
                ))}
                <Button className="rounded-full w-full py-6 text-lg">
                  Apply Now
                </Button>
                <div className="flex flex-col gap-4 mt-8 pt-8 border-t">
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <Phone size={18} className="text-secondary" />
                    <span>+91 7597466803</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <MapPin size={18} className="text-secondary" />
                    <span>Hindaun City, Rajasthan</span>
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
