import { motion } from "motion/react";
import { Phone, Mail, MapPin, MessageCircle, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";

export default function Contact() {
  return (
    <section id="contact" className="py-24 bg-background border-t border-border relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <h2 className="text-4xl md:text-5xl font-serif text-foreground mb-6">
              Get in Touch
            </h2>
            <p className="text-lg text-secondary mb-10 leading-relaxed">
              Have questions about admissions or our facilities? Reach out to us today. We're here to help you make the best choice for your child's future.
            </p>

            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded bg-card border border-border flex items-center justify-center text-primary shrink-0">
                  <Phone size={24} />
                </div>
                <div>
                  <div className="text-[11px] uppercase tracking-widest text-primary font-bold">Call Us</div>
                  <a href="tel:+917597466803" className="text-lg font-serif text-foreground hover:text-primary transition-colors">
                    +91 7597466803
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded bg-card border border-border flex items-center justify-center text-primary shrink-0">
                  <MessageCircle size={24} />
                </div>
                <div>
                  <div className="text-[11px] uppercase tracking-widest text-primary font-bold">WhatsApp</div>
                  <a href="https://t.ly/tnoHz" target="_blank" rel="noreferrer" className="text-lg font-serif text-foreground hover:text-primary transition-colors">
                    Chat with us on WhatsApp
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded bg-card border border-border flex items-center justify-center text-primary shrink-0">
                  <MapPin size={24} />
                </div>
                <div>
                  <div className="text-[11px] uppercase tracking-widest text-primary font-bold">Location</div>
                  <a 
                    href="https://maps.app.goo.gl/YhNpipyeS84m9guUA" 
                    target="_blank" 
                    rel="noreferrer"
                    className="text-lg font-serif text-foreground hover:text-primary transition-colors"
                  >
                    Hindaun City, Rajasthan, India
                  </a>
                </div>
              </div>
            </div>

            <div className="mt-12 rounded-lg overflow-hidden h-[300px] shadow-lg border border-border grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14241.123456789!2d77.0234567!3d26.7234567!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3973d34567890abc%3A0x1234567890abcdef!2sHindaun%2C%20Rajasthan!5e0!3m2!1sen!2sin!4v1623456789012!5m2!1sen!2sin"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <Card className="bg-card border border-border shadow-2xl p-4 md:p-8 rounded-xl">
              <CardContent className="space-y-6">
                <h3 className="text-2xl font-serif text-foreground mb-4">Send us a Message</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[11px] uppercase tracking-widest text-primary font-bold">Full Name</label>
                    <Input placeholder="John Doe" className="bg-background border-border rounded h-12" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[11px] uppercase tracking-widest text-primary font-bold">Phone Number</label>
                    <Input placeholder="+91 00000 00000" className="bg-background border-border rounded h-12" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[11px] uppercase tracking-widest text-primary font-bold">Email Address</label>
                  <Input placeholder="john@example.com" className="bg-background border-border rounded h-12" />
                </div>
                <div className="space-y-2">
                  <label className="text-[11px] uppercase tracking-widest text-primary font-bold">Message</label>
                  <Textarea placeholder="How can we help you?" className="bg-background border-border rounded min-h-[150px]" />
                </div>
                <Button className="cta-btn-primary w-full h-14 rounded group">
                  Send Message
                  <Send className="ml-2 w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
