import { motion } from "motion/react";
import { Button } from "@/components/ui/button";
import { ArrowRight, Play } from "lucide-react";

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-32 pb-20 overflow-hidden bg-background">
      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-[1.2fr_0.8fr] gap-16 items-center relative z-10">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="hero-content"
        >
          <div className="text-primary uppercase tracking-[4px] text-xs font-semibold mb-4">
            Excellence in Education
          </div>
          <h1 className="text-6xl md:text-7xl lg:text-8xl font-serif text-foreground leading-[1.1] mb-8 text-balance">
            Building Future Leaders in Hindaun City.
          </h1>
          <p className="text-lg text-secondary mb-12 max-w-lg leading-relaxed">
            KEMS Boarding School provides a world-class residential learning environment focused on character building, academic rigor, and holistic growth.
          </p>
          
          <div className="flex gap-12">
            <div className="stat-item">
              <span className="block text-foreground font-bold text-2xl">15+</span>
              <span className="text-xs uppercase tracking-widest text-secondary">Years Legacy</span>
            </div>
            <div className="stat-item">
              <span className="block text-foreground font-bold text-2xl">100%</span>
              <span className="text-xs uppercase tracking-widest text-secondary">Success Rate</span>
            </div>
            <div className="stat-item">
              <span className="block text-foreground font-bold text-2xl">10:1</span>
              <span className="text-xs uppercase tracking-widest text-secondary">Student Ratio</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="relative"
        >
          <div className="bg-card border border-border rounded-xl p-10 flex flex-col gap-8 shadow-2xl">
            <div className="flex flex-col gap-2">
              <div className="text-[11px] uppercase text-primary tracking-widest">Contact Admissions</div>
              <div className="text-2xl font-serif text-foreground">+91 75974 66803</div>
            </div>
            
            <div className="flex flex-col gap-2">
              <div className="text-[11px] uppercase text-primary tracking-widest">Our Campus</div>
              <div className="text-2xl font-serif text-foreground">Hindaun City, Rajasthan</div>
            </div>

            <div className="flex flex-col gap-4 mt-4">
              <a href="https://t.ly/tnoHz" target="_blank" rel="noreferrer" className="cta-btn-primary text-center">
                Message on WhatsApp
              </a>
              <a href="https://maps.app.goo.gl/YhNpipyeS84m9guUA" target="_blank" rel="noreferrer" className="cta-btn-outline text-center">
                View on Map
              </a>
            </div>
          </div>
          
          {/* Decorative background glow */}
          <div className="absolute -inset-4 bg-primary/5 blur-3xl -z-10 rounded-full" />
        </motion.div>
      </div>
    </section>
  );
}
