import { motion } from "motion/react";
import { BookOpen, Users, Trophy, ShieldCheck, Coffee, Heart } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const features = [
  {
    title: "Academic Excellence",
    description: "Rigorous curriculum focused on critical thinking and practical knowledge.",
    icon: BookOpen,
    color: "bg-blue-50 text-blue-600",
  },
  {
    title: "Safe Boarding",
    description: "Home-like environment with 24/7 security and caring wardens.",
    icon: ShieldCheck,
    color: "bg-green-50 text-green-600",
  },
  {
    title: "Expert Faculty",
    description: "Highly qualified teachers dedicated to student success.",
    icon: Users,
    color: "bg-purple-50 text-purple-600",
  },
  {
    title: "Sports & Arts",
    description: "Wide range of extracurricular activities for holistic growth.",
    icon: Trophy,
    color: "bg-orange-50 text-orange-600",
  },
  {
    title: "Nutritious Meals",
    description: "Healthy and delicious food prepared in a hygienic kitchen.",
    icon: Coffee,
    color: "bg-red-50 text-red-600",
  },
  {
    title: "Personal Care",
    description: "Individual attention to every student's emotional and physical well-being.",
    icon: Heart,
    color: "bg-pink-50 text-pink-600",
  },
];

export default function Features() {
  return (
    <section id="academics" className="py-24 bg-background border-t border-border relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-serif text-foreground mb-4"
          >
            Why Choose KEMS?
          </motion.h2>
          <p className="text-secondary max-w-2xl mx-auto">
            We provide an environment where students can thrive academically, socially, and personally.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-card border border-border shadow-sm hover:border-primary/50 transition-all duration-300 group">
                <CardContent className="p-8">
                  <div className={`w-14 h-14 rounded ${feature.color.replace('bg-', 'bg-opacity-10 bg-')} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                    <feature.icon size={28} />
                  </div>
                  <h3 className="text-xl font-serif text-foreground mb-3">{feature.title}</h3>
                  <p className="text-secondary leading-relaxed">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
